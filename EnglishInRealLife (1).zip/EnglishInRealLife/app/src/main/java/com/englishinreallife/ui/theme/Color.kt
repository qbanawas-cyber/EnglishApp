package com.englishinreallife.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Colors
val PrimaryLight = Color(0xFF2563EB)
val PrimaryDark = Color(0xFF60A5FA)
val PrimaryContainerLight = Color(0xFFDBEAFE)
val PrimaryContainerDark = Color(0xFF1E40AF)

// Secondary Colors
val SecondaryLight = Color(0xFF059669)
val SecondaryDark = Color(0xFF34D399)
val SecondaryContainerLight = Color(0xFFD1FAE5)
val SecondaryContainerDark = Color(0xFF065F46)

// Accent Colors
val AccentLight = Color(0xFFF59E0B)
val AccentDark = Color(0xFFFBBF24)

// Background Colors
val BackgroundLight = Color(0xFFF8FAFC)
val BackgroundDark = Color(0xFF0F172A)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceDark = Color(0xFF1E293B)

// Error Colors
val ErrorLight = Color(0xFFDC2626)
val ErrorDark = Color(0xFFEF4444)

// Text Colors
val OnBackgroundLight = Color(0xFF1E293B)
val OnBackgroundDark = Color(0xFFF1F5F9)
val OnSurfaceLight = Color(0xFF334155)
val OnSurfaceDark = Color(0xFFCBD5E1)

// Category Colors
val CategoryGreetings = Color(0xFF8B5CF6)
val CategoryFamily = Color(0xFFEC4899)
val CategoryRestaurant = Color(0xFFF97316)
val CategoryShopping = Color(0xFF14B8A6)
val CategoryTravel = Color(0xFF3B82F6)
val CategoryHotel = Color(0xFF6366F1)
val CategoryWork = Color(0xFF10B981)
val CategoryEmergencies = Color(0xFFEF4444)
val CategoryAirport = Color(0xFF06B6D4)
val CategoryDailyLife = Color(0xFF84CC16)
