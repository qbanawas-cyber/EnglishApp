package com.englishinreallife.viewmodel

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.englishinreallife.data.repository.LessonRepository
import com.englishinreallife.model.DialogueLine
import com.englishinreallife.model.Lesson
import com.englishinreallife.model.Vocabulary
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LessonViewModel @Inject constructor(
    private val lessonRepository: LessonRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val lessonId: Int = savedStateHandle.get<Int>("lessonId") ?: 0

    val lesson: StateFlow<Lesson?> = lessonRepository.getLessonById(lessonId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val dialogue: StateFlow<List<DialogueLine>> = 
        lessonRepository.getDialogueForLesson(lessonId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val vocabulary: StateFlow<List<Vocabulary>> = 
        lessonRepository.getVocabularyForLesson(lessonId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val quizzes = lessonRepository.getQuizzesForLesson(lessonId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}
