package com.englishinreallife.data.repository

import com.englishinreallife.data.local.dao.MultiMeaningDao
import com.englishinreallife.model.MultiMeaningWord
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MultiMeaningRepository @Inject constructor(
    private val multiMeaningDao: MultiMeaningDao
) {
    fun getAllWords(): Flow<List<MultiMeaningWord>> = multiMeaningDao.getAllWords()

    fun searchWords(query: String): Flow<List<MultiMeaningWord>> = 
        multiMeaningDao.searchWords(query)

    suspend fun getWordCount(): Int = multiMeaningDao.getWordCount()
}
