package com.englishinreallife.ui.screens.home

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.englishinreallife.ui.components.*
import com.englishinreallife.ui.theme.*
import com.englishinreallife.viewmodel.HomeViewModel
import kotlinx.coroutines.flow.combine

@Composable
fun HomeScreen(
    onCategoryClick: (String) -> Unit,
    onProgressClick: () -> Unit,
    onMultiMeaningClick: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val categories by viewModel.categories.collectAsState(initial = emptyList())
    val lessons by viewModel.lessons.collectAsState(initial = emptyList())
    val userProgress by viewModel.userProgress.collectAsState(initial = null)
    val progressPercentage by viewModel.progressPercentage.collectAsState(initial = 0f)
    val completedCount by viewModel.completedCount.collectAsState(initial = 0)
    val totalCount by viewModel.totalCount.collectAsState(initial = 0)
    val nextLesson by viewModel.nextLesson.collectAsState(initial = null)

    Scaffold(
        topBar = {
            HomeTopBar(
                userName = "Learner",
                points = userProgress?.totalPoints ?: 0,
                streak = userProgress?.currentStreak ?: 0,
                onProgressClick = onProgressClick
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Welcome Section
            item {
                WelcomeSection(
                    completedLessons = completedCount,
                    totalLessons = totalCount,
                    progress = progressPercentage,
                    nextLesson = nextLesson?.title ?: "Start Learning!",
                    nextLessonAr = nextLesson?.titleAr ?: "ابدأ التعلم!"
                )
            }

            // Quick Actions
            item {
                QuickActionsRow(
                    onMultiMeaningClick = onMultiMeaningClick,
                    onProgressClick = onProgressClick
                )
            }

            // Categories Header
            item {
                Text(
                    text = "Lesson Categories",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(top = 8.dp)
                )
                Text(
                    text = "فئات الدروس",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }

            // Categories List
            items(categories) { category ->
                val categoryLessons = lessons.filter { it.category == category }
                val completedInCategory = categoryLessons.count { it.isCompleted }

                CategoryCard(
                    title = category,
                    titleAr = getCategoryArabicName(category),
                    icon = getCategoryIcon(category),
                    color = getCategoryColor(category),
                    lessonCount = categoryLessons.size,
                    completedCount = completedInCategory,
                    onClick = { onCategoryClick(category) }
                )
            }

            // Bottom spacing
            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
fun HomeTopBar(
    userName: String,
    points: Int,
    streak: Int,
    onProgressClick: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 3.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // User Avatar
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(PrimaryLight, SecondaryLight)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = userName.first().toString(),
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Welcome!",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = userName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            // Points
            AnimatedPoints(points = points)

            Spacer(modifier = Modifier.width(12.dp))

            // Streak
            if (streak > 0) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocalFireDepartment,
                        contentDescription = "Streak",
                        tint = Color(0xFFF59E0B),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = "$streak",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFF59E0B)
                    )
                }
            }

            IconButton(onClick = onProgressClick) {
                Icon(
                    imageVector = Icons.Default.EmojiEvents,
                    contentDescription = "Achievements",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
fun WelcomeSection(
    completedLessons: Int,
    totalLessons: Int,
    progress: Float,
    nextLesson: String,
    nextLessonAr: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Your Progress",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "تقدمك",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                    )
                }
                Text(
                    text = "${(progress * 100).toInt()}%",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            ProgressBar(
                progress = progress,
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.1f),
                height = 10
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "$completedLessons of $totalLessons lessons completed",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
            )

            if (completedLessons < totalLessons) {
                Spacer(modifier = Modifier.height(12.dp))
                Surface(
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayCircle,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Continue Learning",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = nextLesson,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                            )
                            Text(
                                text = nextLessonAr,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.5f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuickActionsRow(
    onMultiMeaningClick: () -> Unit,
    onProgressClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        QuickActionCard(
            title = "Multi-Meaning",
            titleAr = "كلمات متعددة المعاني",
            icon = Icons.Default.MenuBook,
            color = CategoryShopping,
            onClick = onMultiMeaningClick,
            modifier = Modifier.weight(1f)
        )
        QuickActionCard(
            title = "My Progress",
            titleAr = "تقدمي",
            icon = Icons.Default.TrendingUp,
            color = CategoryTravel,
            onClick = onProgressClick,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun QuickActionCard(
    title: String,
    titleAr: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = titleAr,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// Helper functions
fun getCategoryColor(category: String): Color = when (category) {
    "Greetings" -> CategoryGreetings
    "Family" -> CategoryFamily
    "Restaurant" -> CategoryRestaurant
    "Shopping" -> CategoryShopping
    "Travel" -> CategoryTravel
    "Hotel" -> CategoryHotel
    "Work" -> CategoryWork
    "Emergencies" -> CategoryEmergencies
    "Airport" -> CategoryAirport
    "Daily Life" -> CategoryDailyLife
    else -> PrimaryLight
}

fun getCategoryIcon(category: String) = when (category) {
    "Greetings" -> Icons.Default.WavingHand
    "Family" -> Icons.Default.People
    "Restaurant" -> Icons.Default.Restaurant
    "Shopping" -> Icons.Default.ShoppingCart
    "Travel" -> Icons.Default.Explore
    "Hotel" -> Icons.Default.Hotel
    "Work" -> Icons.Default.Work
    "Emergencies" -> Icons.Default.Warning
    "Airport" -> Icons.Default.Flight
    "Daily Life" -> Icons.Default.CalendarToday
    else -> Icons.Default.Book
}

fun getCategoryArabicName(category: String): String = when (category) {
    "Greetings" -> "التحيات"
    "Family" -> "العائلة"
    "Restaurant" -> "المطعم"
    "Shopping" -> "التسوق"
    "Travel" -> "السفر"
    "Hotel" -> "الفندق"
    "Work" -> "العمل"
    "Emergencies" -> "الطوارئ"
    "Airport" -> "المطار"
    "Daily Life" -> "الحياة اليومية"
    else -> category
}
