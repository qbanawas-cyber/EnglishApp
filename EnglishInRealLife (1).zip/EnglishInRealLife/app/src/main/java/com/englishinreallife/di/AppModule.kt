package com.englishinreallife.di

import android.content.Context
import androidx.room.Room
import com.englishinreallife.data.local.AppDatabase
import com.englishinreallife.data.local.DataSeeder
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "english_in_real_life.db"
        )
        .fallbackToDestructiveMigration()
        .build()
    }

    @Provides
    fun provideLessonDao(db: AppDatabase) = db.lessonDao()

    @Provides
    fun provideDialogueDao(db: AppDatabase) = db.dialogueDao()

    @Provides
    fun provideVocabularyDao(db: AppDatabase) = db.vocabularyDao()

    @Provides
    fun provideQuizDao(db: AppDatabase) = db.quizDao()

    @Provides
    fun provideMultiMeaningDao(db: AppDatabase) = db.multiMeaningDao()

    @Provides
    fun provideProgressDao(db: AppDatabase) = db.progressDao()

    @Provides
    fun provideAchievementDao(db: AppDatabase) = db.achievementDao()

    @Provides
    @Singleton
    fun provideDataSeeder(
        lessonDao: com.englishinreallife.data.local.dao.LessonDao,
        dialogueDao: com.englishinreallife.data.local.dao.DialogueDao,
        vocabularyDao: com.englishinreallife.data.local.dao.VocabularyDao,
        quizDao: com.englishinreallife.data.local.dao.QuizDao,
        multiMeaningDao: com.englishinreallife.data.local.dao.MultiMeaningDao,
        progressDao: com.englishinreallife.data.local.dao.ProgressDao
    ): DataSeeder {
        return DataSeeder(lessonDao, dialogueDao, vocabularyDao, quizDao, multiMeaningDao, progressDao)
    }
}
