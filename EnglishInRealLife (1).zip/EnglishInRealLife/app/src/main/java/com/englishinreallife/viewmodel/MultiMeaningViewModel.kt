package com.englishinreallife.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.englishinreallife.data.repository.MultiMeaningRepository
import com.englishinreallife.model.MultiMeaningWord
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import javax.inject.Inject

@HiltViewModel
class MultiMeaningViewModel @Inject constructor(
    private val repository: MultiMeaningRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val words: StateFlow<List<MultiMeaningWord>> = 
        repository.getAllWords()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredWords: StateFlow<List<MultiMeaningWord>> = combine(
        words,
        searchQuery
    ) { allWords, query ->
        if (query.isBlank()) allWords
        else allWords.filter { it.word.contains(query, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }
}
