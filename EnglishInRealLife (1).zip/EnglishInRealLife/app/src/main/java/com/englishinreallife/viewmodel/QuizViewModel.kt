package com.englishinreallife.viewmodel

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.englishinreallife.data.repository.LessonRepository
import com.englishinreallife.data.repository.ProgressRepository
import com.englishinreallife.model.Quiz
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class QuizViewModel @Inject constructor(
    private val lessonRepository: LessonRepository,
    private val progressRepository: ProgressRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val lessonId: Int = savedStateHandle.get<Int>("lessonId") ?: 0

    val quizzes: StateFlow<List<Quiz>> = 
        lessonRepository.getQuizzesForLesson(lessonId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentQuestionIndex = MutableStateFlow(0)
    val currentQuestionIndex: StateFlow<Int> = _currentQuestionIndex.asStateFlow()

    private val _score = MutableStateFlow(0)
    val score: StateFlow<Int> = _score.asStateFlow()

    private val _answers = MutableStateFlow<Map<Int, String>>(emptyMap())
    val answers: StateFlow<Map<Int, String>> = _answers.asStateFlow()

    private val _isQuizComplete = MutableStateFlow(false)
    val isQuizComplete: StateFlow<Boolean> = _isQuizComplete.asStateFlow()

    private val _showResults = MutableStateFlow(false)
    val showResults: StateFlow<Boolean> = _showResults.asStateFlow()

    fun submitAnswer(answer: String) {
        viewModelScope.launch {
            val currentQuiz = quizzes.value.getOrNull(_currentQuestionIndex.value) ?: return@launch
            val isCorrect = answer.equals(currentQuiz.correctAnswer, ignoreCase = true)

            _answers.value = _answers.value + (_currentQuestionIndex.value to answer)

            if (isCorrect) {
                _score.value += currentQuiz.points
            }

            if (_currentQuestionIndex.value < quizzes.value.size - 1) {
                _currentQuestionIndex.value += 1
            } else {
                _isQuizComplete.value = true
            }
        }
    }

    fun showResults() {
        _showResults.value = true
        viewModelScope.launch {
            // Update progress
            progressRepository.addPoints(_score.value)
            progressRepository.addExperience(_score.value)
            lessonRepository.markLessonComplete(lessonId, _score.value)

            // Update streak
            val currentTime = System.currentTimeMillis()
            progressRepository.updateLastStudyDate(currentTime)
        }
    }

    fun resetQuiz() {
        _currentQuestionIndex.value = 0
        _score.value = 0
        _answers.value = emptyMap()
        _isQuizComplete.value = false
        _showResults.value = false
    }

    fun getCurrentQuiz(): Quiz? = quizzes.value.getOrNull(_currentQuestionIndex.value)

    fun getTotalQuestions(): Int = quizzes.value.size
}
