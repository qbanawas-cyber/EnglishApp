package com.englishinreallife.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.englishinreallife.data.repository.LessonRepository
import com.englishinreallife.data.repository.ProgressRepository
import com.englishinreallife.model.Achievement
import com.englishinreallife.model.UserProgress
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProgressViewModel @Inject constructor(
    private val progressRepository: ProgressRepository,
    private val lessonRepository: LessonRepository
) : ViewModel() {

    val userProgress: StateFlow<UserProgress?> = 
        progressRepository.getUserProgress()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val achievements: StateFlow<List<Achievement>> = 
        progressRepository.getAllAchievements()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unlockedAchievements: StateFlow<List<Achievement>> = 
        progressRepository.getUnlockedAchievements()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val completedLessonsCount: StateFlow<Int> = 
        lessonRepository.getCompletedCount()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalLessonsCount: StateFlow<Int> = 
        lessonRepository.getTotalCount()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val progressPercentage: StateFlow<Float> = combine(
        completedLessonsCount,
        totalLessonsCount
    ) { completed, total ->
        if (total > 0) completed.toFloat() / total.toFloat() else 0f
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0f)

    fun checkAndUnlockAchievements() {
        viewModelScope.launch {
            val progress = userProgress.value ?: return@launch
            val completed = completedLessonsCount.value
            val currentTime = System.currentTimeMillis()

            // Check achievements
            when {
                completed >= 1 -> progressRepository.unlockAchievement("first_lesson", currentTime)
                completed >= 5 -> progressRepository.unlockAchievement("five_lessons", currentTime)
                completed >= 10 -> progressRepository.unlockAchievement("ten_lessons", currentTime)
                completed >= 20 -> progressRepository.unlockAchievement("all_lessons", currentTime)
            }

            if (progress.currentStreak >= 7) {
                progressRepository.unlockAchievement("streak_7", currentTime)
            }
            if (progress.currentStreak >= 30) {
                progressRepository.unlockAchievement("streak_30", currentTime)
            }
        }
    }
}
