package com.englishinreallife.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "multi_meaning_words")
data class MultiMeaningWord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val word: String,
    val meanings: List<WordMeaning>
)

data class WordMeaning(
    val meaning: String,
    val meaningAr: String,
    val example: String,
    val exampleAr: String
)
