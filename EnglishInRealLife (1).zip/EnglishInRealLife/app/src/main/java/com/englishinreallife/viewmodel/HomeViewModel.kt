package com.englishinreallife.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.englishinreallife.data.repository.LessonRepository
import com.englishinreallife.data.repository.ProgressRepository
import com.englishinreallife.model.Lesson
import com.englishinreallife.model.UserProgress
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val lessonRepository: LessonRepository,
    private val progressRepository: ProgressRepository
) : ViewModel() {

    val categories: Flow<List<String>> = lessonRepository.getAllCategories()

    val lessons: Flow<List<Lesson>> = lessonRepository.getAllLessons()

    val userProgress: Flow<UserProgress?> = progressRepository.getUserProgress()

    val completedCount: Flow<Int> = lessonRepository.getCompletedCount()

    val totalCount: Flow<Int> = lessonRepository.getTotalCount()

    val nextLesson: Flow<Lesson?> = flow {
        emit(lessonRepository.getNextLesson())
    }

    val progressPercentage: Flow<Float> = combine(
        completedCount,
        totalCount
    ) { completed, total ->
        if (total > 0) completed.toFloat() / total.toFloat() else 0f
    }

    fun getLessonsByCategory(category: String): Flow<List<Lesson>> = 
        lessonRepository.getLessonsByCategory(category)
}
