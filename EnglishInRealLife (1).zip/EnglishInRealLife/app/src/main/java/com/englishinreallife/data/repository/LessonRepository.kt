package com.englishinreallife.data.repository

import com.englishinreallife.data.local.dao.*
import com.englishinreallife.model.*
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LessonRepository @Inject constructor(
    private val lessonDao: LessonDao,
    private val dialogueDao: DialogueDao,
    private val vocabularyDao: VocabularyDao,
    private val quizDao: QuizDao
) {
    fun getAllLessons(): Flow<List<Lesson>> = lessonDao.getAllLessons()

    fun getLessonsByCategory(category: String): Flow<List<Lesson>> = 
        lessonDao.getLessonsByCategory(category)

    suspend fun getLessonById(id: Int): Lesson? = lessonDao.getLessonById(id)

    fun getAllCategories(): Flow<List<String>> = lessonDao.getAllCategories()

    fun getDialogueForLesson(lessonId: Int): Flow<List<DialogueLine>> = 
        dialogueDao.getDialogueForLesson(lessonId)

    fun getVocabularyForLesson(lessonId: Int): Flow<List<Vocabulary>> = 
        vocabularyDao.getVocabularyForLesson(lessonId)

    fun getQuizzesForLesson(lessonId: Int): Flow<List<Quiz>> = 
        quizDao.getQuizzesForLesson(lessonId)

    suspend fun markLessonComplete(lessonId: Int, points: Int) {
        lessonDao.markLessonComplete(lessonId, points)
    }

    fun getCompletedCount(): Flow<Int> = lessonDao.getCompletedLessonsCount()

    fun getTotalCount(): Flow<Int> = lessonDao.getTotalLessonsCount()

    suspend fun getNextLesson(): Lesson? = lessonDao.getNextLesson()
}
