package com.englishinreallife.data.local.dao

import androidx.room.*
import com.englishinreallife.model.MultiMeaningWord
import kotlinx.coroutines.flow.Flow

@Dao
interface MultiMeaningDao {

    @Query("SELECT * FROM multi_meaning_words ORDER BY word ASC")
    fun getAllWords(): Flow<List<MultiMeaningWord>>

    @Query("SELECT * FROM multi_meaning_words WHERE word LIKE '%' || :query || '%'")
    fun searchWords(query: String): Flow<List<MultiMeaningWord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWords(words: List<MultiMeaningWord>)

    @Query("SELECT COUNT(*) FROM multi_meaning_words")
    suspend fun getWordCount(): Int
}
