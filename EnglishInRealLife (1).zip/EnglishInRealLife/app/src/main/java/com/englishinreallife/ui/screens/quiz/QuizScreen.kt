package com.englishinreallife.ui.screens.quiz

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.englishinreallife.model.QuestionType
import com.englishinreallife.model.Quiz
import com.englishinreallife.ui.components.AppTopBar
import com.englishinreallife.ui.components.ProgressBar
import com.englishinreallife.viewmodel.QuizViewModel

@Composable
fun QuizScreen(
    lessonId: Int,
    onFinish: () -> Unit,
    onBackClick: () -> Unit,
    viewModel: QuizViewModel = hiltViewModel()
) {
    val quizzes by viewModel.quizzes.collectAsState()
    val currentIndex by viewModel.currentQuestionIndex.collectAsState()
    val score by viewModel.score.collectAsState()
    val isComplete by viewModel.isQuizComplete.collectAsState()
    val showResults by viewModel.showResults.collectAsState()
    val answers by viewModel.answers.collectAsState()

    if (showResults) {
        QuizResultsScreen(
            score = score,
            totalQuestions = quizzes.size,
            totalPossible = quizzes.sumOf { it.points },
            onFinish = onFinish,
            onRetry = { viewModel.resetQuiz() }
        )
    } else if (quizzes.isEmpty()) {
        Scaffold(
            topBar = { AppTopBar(title = "Quiz", onBackClick = onBackClick) }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text("No quizzes available for this lesson yet.")
            }
        }
    } else {
        val currentQuiz = quizzes.getOrNull(currentIndex)

        Scaffold(
            topBar = {
                AppTopBar(
                    title = "Quiz ${currentIndex + 1}/${quizzes.size}",
                    subtitle = "Score: $score",
                    onBackClick = onBackClick
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
            ) {
                // Progress bar
                ProgressBar(
                    progress = (currentIndex + 1).toFloat() / quizzes.size.toFloat(),
                    color = MaterialTheme.colorScheme.primary,
                    height = 8
                )

                Spacer(modifier = Modifier.height(24.dp))

                if (currentQuiz != null) {
                    QuizQuestionCard(
                        quiz = currentQuiz,
                        onAnswerSelected = { answer ->
                            viewModel.submitAnswer(answer)
                        },
                        isComplete = isComplete,
                        selectedAnswer = answers[currentIndex]
                    )
                }

                if (isComplete) {
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = { viewModel.showResults() },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("View Results")
                    }
                }
            }
        }
    }
}

@Composable
fun QuizQuestionCard(
    quiz: Quiz,
    onAnswerSelected: (String) -> Unit,
    isComplete: Boolean,
    selectedAnswer: String?
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Question Type Badge
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = quiz.questionType.name.replace("_", " "),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Question
            Text(
                text = quiz.question,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = quiz.questionAr,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Answer Options based on type
            when (quiz.questionType) {
                QuestionType.MULTIPLE_CHOICE -> {
                    MultipleChoiceOptions(
                        options = quiz.options,
                        correctAnswer = quiz.correctAnswer,
                        selectedAnswer = selectedAnswer,
                        onSelect = onAnswerSelected
                    )
                }
                QuestionType.WORD_ORDERING -> {
                    WordOrderingExercise(
                        words = quiz.options,
                        correctAnswer = quiz.correctAnswer,
                        selectedAnswer = selectedAnswer,
                        onSubmit = onAnswerSelected
                    )
                }
                QuestionType.FILL_BLANK -> {
                    FillBlankOptions(
                        options = quiz.options,
                        correctAnswer = quiz.correctAnswer,
                        selectedAnswer = selectedAnswer,
                        onSelect = onAnswerSelected
                    )
                }
                QuestionType.MATCHING -> {
                    // Simplified matching for MVP
                    MultipleChoiceOptions(
                        options = quiz.options,
                        correctAnswer = quiz.correctAnswer,
                        selectedAnswer = selectedAnswer,
                        onSelect = onAnswerSelected
                    )
                }
            }

            // Show explanation if answered
            AnimatedVisibility(
                visible = selectedAnswer != null,
                enter = fadeIn() + expandVertically()
            ) {
                Column {
                    Spacer(modifier = Modifier.height(16.dp))
                    Surface(
                        color = if (selectedAnswer == quiz.correctAnswer) 
                            MaterialTheme.colorScheme.secondaryContainer 
                        else 
                            MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = if (selectedAnswer == quiz.correctAnswer) "✓ Correct!" else "✗ Incorrect",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedAnswer == quiz.correctAnswer) 
                                    MaterialTheme.colorScheme.onSecondaryContainer 
                                else 
                                    MaterialTheme.colorScheme.onErrorContainer
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = quiz.explanation,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = quiz.explanationAr,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MultipleChoiceOptions(
    options: List<String>,
    correctAnswer: String,
    selectedAnswer: String?,
    onSelect: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { option ->
            val isSelected = selectedAnswer == option
            val isCorrect = option == correctAnswer
            val backgroundColor = when {
                selectedAnswer == null -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                isSelected && isCorrect -> MaterialTheme.colorScheme.secondaryContainer
                isSelected && !isCorrect -> MaterialTheme.colorScheme.errorContainer
                !isSelected && isCorrect -> MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
            }

            val borderColor = when {
                selectedAnswer == null -> MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                isSelected && isCorrect -> MaterialTheme.colorScheme.secondary
                isSelected && !isCorrect -> MaterialTheme.colorScheme.error
                else -> Color.Transparent
            }

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .border(2.dp, borderColor, RoundedCornerShape(12.dp))
                    .clickable(enabled = selectedAnswer == null) { onSelect(option) },
                color = backgroundColor
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = isSelected,
                        onClick = null,
                        enabled = selectedAnswer == null
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = option,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun WordOrderingExercise(
    words: List<String>,
    correctAnswer: String,
    selectedAnswer: String?,
    onSubmit: (String) -> Unit
) {
    var selectedWords by remember { mutableStateOf<List<String>>(emptyList()) }
    var remainingWords by remember { mutableStateOf(words) }

    if (selectedAnswer != null) {
        // Show result state
        Text(
            text = "Your answer: $selectedAnswer",
            style = MaterialTheme.typography.bodyLarge,
            color = if (selectedAnswer == correctAnswer) 
                MaterialTheme.colorScheme.secondary 
            else 
                MaterialTheme.colorScheme.error
        )
    } else {
        Column {
            // Selected words area
            if (selectedWords.isNotEmpty()) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        selectedWords.forEach { word ->
                            AssistChip(
                                onClick = {
                                    selectedWords = selectedWords - word
                                    remainingWords = remainingWords + word
                                },
                                label = { Text(word) }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Remaining words
            Text(
                text = "Tap words in correct order:",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                remainingWords.forEach { word ->
                    Button(
                        onClick = {
                            selectedWords = selectedWords + word
                            remainingWords = remainingWords - word
                        }
                    ) {
                        Text(word)
                    }
                }
            }

            if (remainingWords.isEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { onSubmit(selectedWords.joinToString(" ")) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Submit Answer")
                }
            }
        }
    }
}

@Composable
fun FillBlankOptions(
    options: List<String>,
    correctAnswer: String,
    selectedAnswer: String?,
    onSelect: (String) -> Unit
) {
    // Similar to multiple choice but styled differently
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "Choose the correct word to fill the blank:",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))

        options.forEach { option ->
            val isSelected = selectedAnswer == option
            val isCorrect = option == correctAnswer

            val backgroundColor = when {
                selectedAnswer == null -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                isSelected && isCorrect -> MaterialTheme.colorScheme.secondaryContainer
                isSelected && !isCorrect -> MaterialTheme.colorScheme.errorContainer
                else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
            }

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable(enabled = selectedAnswer == null) { onSelect(option) },
                color = backgroundColor
            ) {
                Text(
                    text = option,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
fun QuizResultsScreen(
    score: Int,
    totalQuestions: Int,
    totalPossible: Int,
    onFinish: () -> Unit,
    onRetry: () -> Unit
) {
    val percentage = if (totalPossible > 0) score.toFloat() / totalPossible.toFloat() else 0f
    val isPerfect = percentage >= 0.9f

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Animated score circle
            val scale by animateFloatAsState(
                targetValue = 1f,
                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                label = "score_scale"
            )

            Box(
                modifier = Modifier
                    .size(200.dp)
                    .scale(scale)
                    .clip(CircleShape)
                    .background(
                        if (isPerfect) MaterialTheme.colorScheme.secondaryContainer
                        else MaterialTheme.colorScheme.primaryContainer
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$score",
                        style = MaterialTheme.typography.displayLarge,
                        fontWeight = FontWeight.Bold,
                        color = if (isPerfect) MaterialTheme.colorScheme.secondary
                        else MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "out of $totalPossible",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = if (isPerfect) "🎉 Perfect Score!" else "Quiz Complete!",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "You answered $totalQuestions questions",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            if (isPerfect) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "⭐ Achievement Unlocked: Perfect Score!",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = onFinish,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Home, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Back to Home")
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = onRetry,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Try Again")
            }
        }
    }
}
