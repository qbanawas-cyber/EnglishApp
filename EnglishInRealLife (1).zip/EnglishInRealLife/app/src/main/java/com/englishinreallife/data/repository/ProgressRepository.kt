package com.englishinreallife.data.repository

import com.englishinreallife.data.local.dao.ProgressDao
import com.englishinreallife.model.Achievement
import com.englishinreallife.model.UserProgress
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ProgressRepository @Inject constructor(
    private val progressDao: ProgressDao
) {
    fun getUserProgress(): Flow<UserProgress?> = progressDao.getUserProgress()

    suspend fun addPoints(points: Int) = progressDao.addPoints(points)

    suspend fun addExperience(xp: Int) = progressDao.addExperience(xp)

    suspend fun updateStreak(streak: Int) = progressDao.updateStreak(streak)

    suspend fun updateLastStudyDate(date: Long) = progressDao.updateLastStudyDate(date)

    fun getAllAchievements(): Flow<List<Achievement>> = progressDao.getAllAchievements()

    fun getUnlockedAchievements(): Flow<List<Achievement>> = progressDao.getUnlockedAchievements()

    suspend fun unlockAchievement(id: String, date: Long) = 
        progressDao.unlockAchievement(id, date)

    suspend fun initializeProgress() {
        val existing = progressDao.getUserProgress()
        // Progress flow is cold, so we handle initialization in DataSeeder
    }
}
