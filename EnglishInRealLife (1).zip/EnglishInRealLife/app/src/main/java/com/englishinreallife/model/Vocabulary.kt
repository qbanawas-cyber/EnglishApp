package com.englishinreallife.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "vocabulary",
    foreignKeys = [
        ForeignKey(
            entity = Lesson::class,
            parentColumns = ["id"],
            childColumns = ["lessonId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("lessonId")]
)
data class Vocabulary(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val lessonId: Int,
    val word: String,
    val meaning: String,
    val meaningAr: String,
    val example: String,
    val exampleAr: String,
    val pronunciation: String
)
