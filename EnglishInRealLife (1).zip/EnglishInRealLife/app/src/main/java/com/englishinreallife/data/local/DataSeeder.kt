package com.englishinreallife.data.local

import com.englishinreallife.data.local.dao.*
import com.englishinreallife.model.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DataSeeder @Inject constructor(
    private val lessonDao: LessonDao,
    private val dialogueDao: DialogueDao,
    private val vocabularyDao: VocabularyDao,
    private val quizDao: QuizDao,
    private val multiMeaningDao: MultiMeaningDao,
    private val progressDao: ProgressDao
) {

    suspend fun seedDatabaseIfEmpty() {
        val lessonCount = lessonDao.getTotalLessonsCount()
        // Since it's a Flow, we need to collect it - but for seeding we'll check differently
        // In practice, we'd check if data exists
        seedLessons()
        seedMultiMeaningWords()
        seedAchievements()
        seedProgress()
    }

    private suspend fun seedLessons() {
        val lessons = listOf(
            // GREETINGS (2 lessons)
            Lesson(1, "Greetings", "Greetings & Introductions", "التحيات والتعريف", 
                "Learn basic greetings and how to introduce yourself", 
                "تعلم التحيات الأساسية وكيفية تقديم نفسك", 
                DifficultyLevel.BEGINNER, 1),
            Lesson(2, "Greetings", "Formal Introductions", "التعريف الرسمي",
                "Master formal introductions in professional settings",
                "إتقان التعريف الرسمي في البيئات المهنية",
                DifficultyLevel.BEGINNER, 2),

            // FAMILY (2 lessons)
            Lesson(3, "Family", "Family Members", "أفراد العائلة",
                "Learn vocabulary for family relationships",
                "تعلم مفردات العلاقات العائلية",
                DifficultyLevel.BEGINNER, 3),
            Lesson(4, "Family", "Describing Family", "وصف العائلة",
                "Talk about your family with descriptive language",
                "تحدث عن عائلتك باستخدام لغة وصفية",
                DifficultyLevel.BEGINNER, 4),

            // RESTAURANT (2 lessons)
            Lesson(5, "Restaurant", "Ordering Food", "طلب الطعام",
                "Learn how to order food at a restaurant",
                "تعلم كيفية طلب الطعام في المطعم",
                DifficultyLevel.BEGINNER, 5),
            Lesson(6, "Restaurant", "Restaurant Conversations", "محادثات المطعم",
                "Handle common restaurant situations",
                "التعامل مع المواقف الشائعة في المطعم",
                DifficultyLevel.INTERMEDIATE, 6),

            // SHOPPING (2 lessons)
            Lesson(7, "Shopping", "At the Store", "في المتجر",
                "Essential shopping vocabulary and phrases",
                "مفردات وعبارات التسوق الأساسية",
                DifficultyLevel.BEGINNER, 7),
            Lesson(8, "Shopping", "Bargaining & Payment", "المفاوضة والدفع",
                "Learn to negotiate prices and pay",
                "تعلم التفاوض على الأسعار والدفع",
                DifficultyLevel.INTERMEDIATE, 8),

            // TRAVEL (2 lessons)
            Lesson(9, "Travel", "Asking for Directions", "طلب الاتجاهات",
                "Navigate new places by asking for help",
                "التنقل في أماكن جديدة بطلب المساعدة",
                DifficultyLevel.BEGINNER, 9),
            Lesson(10, "Travel", "Public Transportation", "المواصلات العامة",
                "Use buses, trains, and taxis effectively",
                "استخدام الحافلات والقطارات والسيارات بفعالية",
                DifficultyLevel.INTERMEDIATE, 10),

            // HOTEL (2 lessons)
            Lesson(11, "Hotel", "Checking In", "تسجيل الدخول",
                "Handle hotel check-in procedures smoothly",
                "التعامل مع إجراءات تسجيل الدخول في الفندق",
                DifficultyLevel.BEGINNER, 11),
            Lesson(12, "Hotel", "Hotel Services", "خدمات الفندق",
                "Request hotel services and handle issues",
                "طلب خدمات الفندق والتعامل مع المشاكل",
                DifficultyLevel.INTERMEDIATE, 12),

            // WORK (2 lessons)
            Lesson(13, "Work", "Job Interview", "المقابلة الوظيفية",
                "Prepare for common job interview questions",
                "الاستعداد لأسئلة المقابلة الوظيفية الشائعة",
                DifficultyLevel.INTERMEDIATE, 13),
            Lesson(14, "Work", "Office Communication", "التواصل المكتبي",
                "Communicate effectively in the workplace",
                "التواصل بفعالية في مكان العمل",
                DifficultyLevel.INTERMEDIATE, 14),

            // EMERGENCIES (2 lessons)
            Lesson(15, "Emergencies", "Medical Emergency", "الطوارئ الطبية",
                "Handle medical emergencies and seek help",
                "التعامل مع الطوارئ الطبية وطلب المساعدة",
                DifficultyLevel.INTERMEDIATE, 15),
            Lesson(16, "Emergencies", "Calling for Help", "الاتصال بالمساعدة",
                "Make emergency calls and report situations",
                "إجراء مكالمات الطوارئ والإبلاغ عن المواقف",
                DifficultyLevel.INTERMEDIATE, 16),

            // AIRPORT (2 lessons)
            Lesson(17, "Airport", "At the Airport", "في المطار",
                "Navigate airport procedures confidently",
                "التنقل في إجراءات المطار بثقة",
                DifficultyLevel.BEGINNER, 17),
            Lesson(18, "Airport", "Immigration & Customs", "الهجرة والجمارك",
                "Handle immigration and customs conversations",
                "التعامل مع محادثات الهجرة والجمارك",
                DifficultyLevel.INTERMEDIATE, 18),

            // DAILY LIFE (2 lessons)
            Lesson(19, "Daily Life", "Morning Routine", "الروتين الصباحي",
                "Describe your daily morning activities",
                "وصف أنشطتك الصباحية اليومية",
                DifficultyLevel.BEGINNER, 19),
            Lesson(20, "Daily Life", "Making Plans", "وضع الخطط",
                "Make and discuss plans with friends",
                "وضع ومناقشة الخطط مع الأصدقاء",
                DifficultyLevel.INTERMEDIATE, 20)
        )

        lessonDao.insertLessons(lessons)

        // Seed dialogues for Lesson 1 (Greetings)
        val greetingsDialogue = listOf(
            DialogueLine(lessonId = 1, speaker = "Sarah", 
                english = "Hello! My name is Sarah. What's your name?",
                arabic = "مرحباً! اسمي سارة. ما اسمك؟",
                orderIndex = 1),
            DialogueLine(lessonId = 1, speaker = "Ahmed",
                english = "Hi Sarah! I'm Ahmed. Nice to meet you!",
                arabic = "مرحباً سارة! أنا أحمد. تشرفت بلقائك!",
                orderIndex = 2),
            DialogueLine(lessonId = 1, speaker = "Sarah",
                english = "Nice to meet you too, Ahmed. Where are you from?",
                arabic = "تشرفت بلقائك أيضاً يا أحمد. من أين أنت؟",
                orderIndex = 3),
            DialogueLine(lessonId = 1, speaker = "Ahmed",
                english = "I'm from Egypt. I live in Cairo. How about you?",
                arabic = "أنا من مصر. أعيش في القاهرة. وماذا عنك؟",
                orderIndex = 4),
            DialogueLine(lessonId = 1, speaker = "Sarah",
                english = "I'm from the United States. I live in New York City.",
                arabic = "أنا من الولايات المتحدة. أعيش في مدينة نيويورك.",
                orderIndex = 5),
            DialogueLine(lessonId = 1, speaker = "Ahmed",
                english = "That's wonderful! What do you do for work?",
                arabic = "هذا رائع! ماذا تعمل؟",
                orderIndex = 6),
            DialogueLine(lessonId = 1, speaker = "Sarah",
                english = "I'm a teacher. I teach English at a language school.",
                arabic = "أنا معلمة. أدرس اللغة الإنجليزية في مدرسة لغات.",
                orderIndex = 7),
            DialogueLine(lessonId = 1, speaker = "Ahmed",
                english = "That's great! I'm a software engineer. I build mobile apps.",
                arabic = "هذا رائع! أنا مهندس برمجيات. أبني تطبيقات الهاتف المحمول.",
                orderIndex = 8)
        )
        dialogueDao.insertDialogueLines(greetingsDialogue)

        // Seed dialogues for Lesson 5 (Restaurant - Ordering Food)
        val restaurantDialogue = listOf(
            DialogueLine(lessonId = 5, speaker = "Waiter",
                english = "Good evening! Welcome to our restaurant. Do you have a reservation?",
                arabic = "مساء الخير! أهلاً بكم في مطعمنا. هل لديكم حجز؟",
                orderIndex = 1),
            DialogueLine(lessonId = 5, speaker = "Customer",
                english = "No, we don't. Do you have a table for two available?",
                arabic = "لا، ليس لدينا. هل يوجد طاولة لشخصين متاحة؟",
                orderIndex = 2),
            DialogueLine(lessonId = 5, speaker = "Waiter",
                english = "Yes, of course. Right this way, please. Here's the menu.",
                arabic = "نعم، بالطبع. تفضلوا من هنا. إليكم قائمة الطعام.",
                orderIndex = 3),
            DialogueLine(lessonId = 5, speaker = "Customer",
                english = "Thank you. What do you recommend today?",
                arabic = "شكراً. ماذا توصي اليوم؟",
                orderIndex = 4),
            DialogueLine(lessonId = 5, speaker = "Waiter",
                english = "Our chef's special is grilled salmon with vegetables. It's very popular.",
                arabic = "طبق الشيف المميز هو سمك السلمون المشوي مع الخضروات. إنه مشهور جداً.",
                orderIndex = 5),
            DialogueLine(lessonId = 5, speaker = "Customer",
                english = "That sounds delicious! I'll have that, please. And a glass of water.",
                arabic = "هذا يبدو لذيذاً! سآخذ ذلك من فضلك. وكأس ماء.",
                orderIndex = 6),
            DialogueLine(lessonId = 5, speaker = "Waiter",
                english = "Excellent choice! Would you like anything to start? Soup or salad?",
                arabic = "اختيار ممتاز! هل تريد شيئاً للبدء؟ شوربة أو سلطة؟",
                orderIndex = 7),
            DialogueLine(lessonId = 5, speaker = "Customer",
                english = "I'll have the Caesar salad, please. And no onions, I'm allergic.",
                arabic = "سآخذ سلطة القيصر من فضلك. وبدون بصل، أنا مصاب بالحساسية.",
                orderIndex = 8)
        )
        dialogueDao.insertDialogueLines(restaurantDialogue)

        // Seed vocabulary for Lesson 1
        val greetingsVocab = listOf(
            Vocabulary(lessonId = 1, word = "Hello", meaning = "A greeting used when meeting someone", 
                meaningAr = "تحية تستخدم عند لقاء شخص", 
                example = "Hello, how are you today?", 
                exampleAr = "مرحباً، كيف حالك اليوم؟",
                pronunciation = "/həˈloʊ/"),
            Vocabulary(lessonId = 1, word = "Nice to meet you", 
                meaning = "A polite expression used when meeting someone for the first time",
                meaningAr = "تعبير مهذب يستخدم عند لقاء شخص لأول مرة",
                example = "Nice to meet you, I'm John.",
                exampleAr = "تشرفت بلقائك، أنا جون.",
                pronunciation = "/naɪs tuː miːt juː/"),
            Vocabulary(lessonId = 1, word = "Where are you from?",
                meaning = "A question asking about someone's origin or hometown",
                meaningAr = "سؤال يطلب معرفة أصل شخص أو مسقط رأسه",
                example = "Where are you from? I'm from London.",
                exampleAr = "من أين أنت؟ أنا من لندن.",
                pronunciation = "/wɛər ɑːr juː frʌm/"),
            Vocabulary(lessonId = 1, word = "What do you do?",
                meaning = "A question asking about someone's job or profession",
                meaningAr = "سؤال يطلب معرفة عمل شخص أو مهنته",
                example = "What do you do? I'm a doctor.",
                exampleAr = "ماذا تعمل؟ أنا طبيب.",
                pronunciation = "/wʌt duː juː duː/")
        )
        vocabularyDao.insertVocabulary(greetingsVocab)

        // Seed vocabulary for Lesson 5
        val restaurantVocab = listOf(
            Vocabulary(lessonId = 5, word = "Reservation",
                meaning = "An arrangement to have a table kept for you at a restaurant",
                meaningAr = "ترتيب لحجز طاولة في المطعم",
                example = "I'd like to make a reservation for tonight.",
                exampleAr = "أود حجز طاولة لهذه الليلة.",
                pronunciation = "/ˌrɛzərˈveɪʃən/"),
            Vocabulary(lessonId = 5, word = "Recommend",
                meaning = "To suggest something as being good or suitable",
                meaningAr = "يقترح شيئاً باعتباره جيداً أو مناسباً",
                example = "Can you recommend a good restaurant?",
                exampleAr = "هل يمكنك أن توصي بمطعم جيد؟",
                pronunciation = "/ˌrɛkəˈmɛnd/"),
            Vocabulary(lessonId = 5, word = "Allergic",
                meaning = "Having a bad reaction to a particular food or substance",
                meaningAr = "يعاني من رد فعل سلبي تجاه طعام أو مادة معينة",
                example = "I'm allergic to peanuts.",
                exampleAr = "أنا مصاب بالحساسية من الفول السوداني.",
                pronunciation = "/əˈlɜːrdʒɪk/"),
            Vocabulary(lessonId = 5, word = "Delicious",
                meaning = "Having a very pleasant taste",
                meaningAr = "ذو طعم لذيذ جداً",
                example = "This cake is absolutely delicious!",
                exampleAr = "هذه الكعكة لذيذة للغاية!",
                pronunciation = "/dɪˈlɪʃəs/")
        )
        vocabularyDao.insertVocabulary(restaurantVocab)

        // Seed quizzes for Lesson 1
        val greetingsQuizzes = listOf(
            Quiz(lessonId = 1, 
                question = "What does 'Nice to meet you' mean?",
                questionAr = "ماذا يعني 'Nice to meet you'؟",
                questionType = QuestionType.MULTIPLE_CHOICE,
                options = listOf("Goodbye", "A greeting for first meetings", "See you later", "Thank you"),
                correctAnswer = "A greeting for first meetings",
                explanation = "'Nice to meet you' is used when you meet someone for the first time.",
                explanationAr = "'Nice to meet you' تستخدم عند لقاء شخص لأول مرة."),
            Quiz(lessonId = 1,
                question = "Complete: '_____ to meet you, I'm John.'",
                questionAr = "أكمل: '_____ to meet you, I'm John.'",
                questionType = QuestionType.FILL_BLANK,
                options = listOf("Nice", "Good", "Hello", "Bye"),
                correctAnswer = "Nice",
                explanation = "The correct phrase is 'Nice to meet you'.",
                explanationAr = "العبارة الصحيحة هي 'Nice to meet you'."),
            Quiz(lessonId = 1,
                question = "Arrange these words: 'are / Where / from / you?'",
                questionAr = "رتب هذه الكلمات: 'are / Where / from / you?'",
                questionType = QuestionType.WORD_ORDERING,
                options = listOf("Where", "are", "you", "from"),
                correctAnswer = "Where are you from?",
                explanation = "The correct order is: Where + are + you + from?",
                explanationAr = "الترتيب الصحيح هو: Where + are + you + from?")
        )
        quizDao.insertQuizzes(greetingsQuizzes)

        // Seed quizzes for Lesson 5
        val restaurantQuizzes = listOf(
            Quiz(lessonId = 5,
                question = "What does 'reservation' mean in a restaurant?",
                questionAr = "ماذا يعني 'reservation' في المطعم؟",
                questionType = QuestionType.MULTIPLE_CHOICE,
                options = listOf("A type of food", "A table booking", "A menu item", "A payment method"),
                correctAnswer = "A table booking",
                explanation = "A reservation is when you book a table in advance.",
                explanationAr = "الحجز هو عندما تحجز طاولة مسبقاً."),
            Quiz(lessonId = 5,
                question = "If someone is 'allergic' to peanuts, they should:",
                questionAr = "إذا كان شخص 'allergic' للفول السوداني، يجب أن:",
                questionType = QuestionType.MULTIPLE_CHOICE,
                options = listOf("Eat more peanuts", "Avoid peanuts", "Cook peanuts", "Buy peanuts"),
                correctAnswer = "Avoid peanuts",
                explanation = "Being allergic means you must avoid that substance.",
                explanationAr = "الإصابة بالحساسية تعني أنه يجب تجنب تلك المادة.")
        )
        quizDao.insertQuizzes(restaurantQuizzes)
    }

    private suspend fun seedMultiMeaningWords() {
        val words = listOf(
            MultiMeaningWord(
                word = "Book",
                meanings = listOf(
                    WordMeaning(
                        meaning = "A set of printed pages bound together",
                        meaningAr = "مجموعة من الصفحات المطبوعة مربوطة معاً",
                        example = "I read an interesting book last night.",
                        exampleAr = "قرأت كتاباً ممتعاً الليلة الماضية."
                    ),
                    WordMeaning(
                        meaning = "To reserve something in advance",
                        meaningAr = "حجز شيء مسبقاً",
                        example = "I need to book a flight to Paris.",
                        exampleAr = "أحتاج لحجز رحلة طيران إلى باريس."
                    )
                )
            ),
            MultiMeaningWord(
                word = "Watch",
                meanings = listOf(
                    WordMeaning(
                        meaning = "A small timepiece worn on the wrist",
                        meaningAr = "ساعة صغيرة تُلبس في المعصم",
                        example = "My watch shows it's 3 o'clock.",
                        exampleAr = "ساعتي تُظهر أن الساعة الثالثة."
                    ),
                    WordMeaning(
                        meaning = "To look at or observe carefully",
                        meaningAr = "النظر إلى شيء أو مراقبته بعناية",
                        example = "Let's watch the sunset together.",
                        exampleAr = "دعنا نشاهد غروب الشمس معاً."
                    )
                )
            ),
            MultiMeaningWord(
                word = "Play",
                meanings = listOf(
                    WordMeaning(
                        meaning = "To engage in an activity for enjoyment",
                        meaningAr = "المشاركة في نشاط للاستمتاع",
                        example = "The children play in the park every day.",
                        exampleAr = "الأطفال يلعبون في الحديقة كل يوم."
                    ),
                    WordMeaning(
                        meaning = "A theatrical performance",
                        meaningAr = "عرض مسرحي",
                        example = "We went to see a play at the theater.",
                        exampleAr = "ذهبنا لمشاهدة مسرحية في المسرح."
                    )
                )
            ),
            MultiMeaningWord(
                word = "Bank",
                meanings = listOf(
                    WordMeaning(
                        meaning = "A financial institution for saving and lending money",
                        meaningAr = "مؤسسة مالية للادخار وإقراض المال",
                        example = "I need to go to the bank to withdraw money.",
                        exampleAr = "أحتاج للذهاب إلى البنك لسحب المال."
                    ),
                    WordMeaning(
                        meaning = "The side of a river or lake",
                        meaningAr = "جانب النهر أو البحيرة",
                        example = "We sat on the bank and watched the ducks.",
                        exampleAr = "جلستنا على ضفة النهر وشاهدنا البط."
                    )
                )
            ),
            MultiMeaningWord(
                word = "Right",
                meanings = listOf(
                    WordMeaning(
                        meaning = "Correct or true",
                        meaningAr = "صحيح أو حقيقي",
                        example = "Your answer is right!",
                        exampleAr = "إجابتك صحيحة!"
                    ),
                    WordMeaning(
                        meaning = "The opposite of left",
                        meaningAr = "عكس اليسار",
                        example = "Turn right at the next intersection.",
                        exampleAr = "انعطف يميناً عند التقاطع القادم."
                    )
                )
            ),
            MultiMeaningWord(
                word = "Date",
                meanings = listOf(
                    WordMeaning(
                        meaning = "A specific day on the calendar",
                        meaningAr = "يوم محدد في التقويم",
                        example = "What's the date today?",
                        exampleAr = "ما هو التاريخ اليوم؟"
                    ),
                    WordMeaning(
                        meaning = "A sweet fruit from a palm tree",
                        meaningAr = "فاكهة حلوة من نخلة",
                        example = "Dates are very popular in Middle Eastern cuisine.",
                        exampleAr = "التمر شائع جداً في المطبخ الشرق أوسطي."
                    ),
                    WordMeaning(
                        meaning = "A social outing with a romantic partner",
                        meaningAr = "خروجة اجتماعية مع شريك رومانسي",
                        example = "They went on a date to the cinema.",
                        exampleAr = "ذهبا في موعد إلى السينما."
                    )
                )
            )
        )
        multiMeaningDao.insertWords(words)
    }

    private suspend fun seedAchievements() {
        val achievements = listOf(
            Achievement("first_lesson", "First Steps", "الخطوات الأولى",
                "Complete your first lesson", "أكمل درسك الأول",
                "emoji_events", 10),
            Achievement("five_lessons", "Quick Learner", "متعلم سريع",
                "Complete 5 lessons", "أكمل 5 دروس",
                "emoji_school", 50),
            Achievement("ten_lessons", "Halfway There", "في منتصف الطريق",
                "Complete 10 lessons", "أكمل 10 دروس",
                "emoji_military", 100),
            Achievement("all_lessons", "English Master", "سيد الإنجليزية",
                "Complete all 20 lessons", "أكمل جميع الـ 20 درساً",
                "emoji_workspace_premium", 200),
            Achievement("perfect_quiz", "Perfect Score", "النتيجة المثالية",
                "Get 100% on a quiz", "احصل على 100% في اختبار",
                "emoji_stars", 50),
            Achievement("streak_7", "Week Warrior", "محارب الأسبوع",
                "Maintain a 7-day streak", "حافظ على سلسلة 7 أيام",
                "emoji_local_fire_department", 70),
            Achievement("streak_30", "Monthly Master", "سيد الشهر",
                "Maintain a 30-day streak", "حافظ على سلسلة 30 يوماً",
                "emoji_calendar_month", 300)
        )
        progressDao.insertAchievements(achievements)
    }

    private suspend fun seedProgress() {
        val progress = UserProgress(
            id = 1,
            totalPoints = 0,
            completedLessons = 0,
            currentStreak = 0,
            longestStreak = 0,
            lastStudyDate = 0,
            currentLevel = 1,
            experiencePoints = 0
        )
        progressDao.insertProgress(progress)
    }
}
