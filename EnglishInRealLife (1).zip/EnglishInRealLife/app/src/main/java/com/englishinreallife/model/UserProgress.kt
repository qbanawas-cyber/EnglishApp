package com.englishinreallife.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_progress")
data class UserProgress(
    @PrimaryKey
    val id: Int = 1,
    val totalPoints: Int = 0,
    val completedLessons: Int = 0,
    val currentStreak: Int = 0,
    val longestStreak: Int = 0,
    val lastStudyDate: Long = 0,
    val currentLevel: Int = 1,
    val experiencePoints: Int = 0
)

@Entity(tableName = "achievements")
data class Achievement(
    @PrimaryKey
    val id: String,
    val title: String,
    val titleAr: String,
    val description: String,
    val descriptionAr: String,
    val iconName: String,
    val requiredPoints: Int,
    val isUnlocked: Boolean = false,
    val unlockedDate: Long? = null
)
