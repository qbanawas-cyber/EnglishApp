package com.englishinreallife.data.local.dao

import androidx.room.*
import com.englishinreallife.model.Achievement
import com.englishinreallife.model.UserProgress
import kotlinx.coroutines.flow.Flow

@Dao
interface ProgressDao {

    @Query("SELECT * FROM user_progress WHERE id = 1")
    fun getUserProgress(): Flow<UserProgress?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProgress(progress: UserProgress)

    @Query("UPDATE user_progress SET totalPoints = totalPoints + :points, completedLessons = completedLessons + 1 WHERE id = 1")
    suspend fun addPoints(points: Int)

    @Query("UPDATE user_progress SET experiencePoints = experiencePoints + :xp, currentLevel = CASE WHEN experiencePoints + :xp >= currentLevel * 100 THEN currentLevel + 1 ELSE currentLevel END WHERE id = 1")
    suspend fun addExperience(xp: Int)

    @Query("UPDATE user_progress SET currentStreak = :streak, longestStreak = CASE WHEN :streak > longestStreak THEN :streak ELSE longestStreak END WHERE id = 1")
    suspend fun updateStreak(streak: Int)

    @Query("UPDATE user_progress SET lastStudyDate = :date WHERE id = 1")
    suspend fun updateLastStudyDate(date: Long)

    // Achievements
    @Query("SELECT * FROM achievements")
    fun getAllAchievements(): Flow<List<Achievement>>

    @Query("SELECT * FROM achievements WHERE isUnlocked = 1")
    fun getUnlockedAchievements(): Flow<List<Achievement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAchievements(achievements: List<Achievement>)

    @Query("UPDATE achievements SET isUnlocked = 1, unlockedDate = :date WHERE id = :achievementId")
    suspend fun unlockAchievement(achievementId: String, date: Long)
}
