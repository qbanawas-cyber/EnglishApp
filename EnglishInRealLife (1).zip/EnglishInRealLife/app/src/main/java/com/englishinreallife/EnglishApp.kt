package com.englishinreallife

import android.app.Application
import com.englishinreallife.data.local.DataSeeder
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltAndroidApp
class EnglishApp : Application() {

    @Inject
    lateinit var dataSeeder: DataSeeder

    override fun onCreate() {
        super.onCreate()

        // Seed database on first launch
        CoroutineScope(Dispatchers.IO).launch {
            dataSeeder.seedDatabaseIfEmpty()
        }
    }
}
