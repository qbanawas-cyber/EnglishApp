package com.englishinreallife.data.local

import androidx.room.TypeConverter
import com.englishinreallife.model.DifficultyLevel
import com.englishinreallife.model.QuestionType
import com.englishinreallife.model.WordMeaning
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class Converters {

    @TypeConverter
    fun fromDifficultyLevel(value: DifficultyLevel): String = value.name

    @TypeConverter
    fun toDifficultyLevel(value: String): DifficultyLevel = 
        DifficultyLevel.valueOf(value)

    @TypeConverter
    fun fromQuestionType(value: QuestionType): String = value.name

    @TypeConverter
    fun toQuestionType(value: String): QuestionType = 
        QuestionType.valueOf(value)

    @TypeConverter
    fun fromStringList(value: List<String>): String = 
        Json.encodeToString(value)

    @TypeConverter
    fun toStringList(value: String): List<String> = 
        Json.decodeFromString(value)

    @TypeConverter
    fun fromWordMeaningList(value: List<WordMeaning>): String = 
        Json.encodeToString(value)

    @TypeConverter
    fun toWordMeaningList(value: String): List<WordMeaning> = 
        Json.decodeFromString(value)
}
