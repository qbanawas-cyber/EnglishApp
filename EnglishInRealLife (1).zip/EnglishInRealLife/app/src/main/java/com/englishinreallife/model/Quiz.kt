package com.englishinreallife.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "quizzes",
    foreignKeys = [
        ForeignKey(
            entity = Lesson::class,
            parentColumns = ["id"],
            childColumns = ["lessonId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("lessonId")]
)
data class Quiz(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val lessonId: Int,
    val question: String,
    val questionAr: String,
    val questionType: QuestionType,
    val options: List<String>,
    val correctAnswer: String,
    val explanation: String,
    val explanationAr: String,
    val points: Int = 10
)

enum class QuestionType {
    MULTIPLE_CHOICE,
    WORD_ORDERING,
    FILL_BLANK,
    MATCHING
}
