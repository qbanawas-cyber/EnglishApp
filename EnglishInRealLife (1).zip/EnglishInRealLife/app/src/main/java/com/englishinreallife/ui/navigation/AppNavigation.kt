package com.englishinreallife.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.englishinreallife.ui.screens.home.HomeScreen
import com.englishinreallife.ui.screens.lessons.LessonsScreen
import com.englishinreallife.ui.screens.lessons.LessonDetailScreen
import com.englishinreallife.ui.screens.quiz.QuizScreen
import com.englishinreallife.ui.screens.progress.ProgressScreen
import com.englishinreallife.ui.screens.multimeaning.MultiMeaningScreen
import com.englishinreallife.ui.screens.lessons.VocabularyScreen

@Composable
fun AppNavigation(
    navController: NavHostController = rememberNavController()
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                onCategoryClick = { category ->
                    navController.navigate(Screen.Lessons.createRoute(category))
                },
                onProgressClick = {
                    navController.navigate(Screen.Progress.route)
                },
                onMultiMeaningClick = {
                    navController.navigate(Screen.MultiMeaning.route)
                }
            )
        }

        composable(
            route = Screen.Lessons.route,
            arguments = listOf(navArgument("category") { type = NavType.StringType })
        ) { backStackEntry ->
            val category = backStackEntry.arguments?.getString("category") ?: ""
            LessonsScreen(
                category = category,
                onLessonClick = { lessonId ->
                    navController.navigate(Screen.LessonDetail.createRoute(lessonId))
                },
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.LessonDetail.route,
            arguments = listOf(navArgument("lessonId") { type = NavType.IntType })
        ) { backStackEntry ->
            val lessonId = backStackEntry.arguments?.getInt("lessonId") ?: 0
            LessonDetailScreen(
                lessonId = lessonId,
                onBackClick = { navController.popBackStack() },
                onQuizClick = {
                    navController.navigate(Screen.Quiz.createRoute(lessonId))
                },
                onVocabularyClick = {
                    navController.navigate(Screen.Vocabulary.createRoute(lessonId))
                }
            )
        }

        composable(
            route = Screen.Quiz.route,
            arguments = listOf(navArgument("lessonId") { type = NavType.IntType })
        ) { backStackEntry ->
            val lessonId = backStackEntry.arguments?.getInt("lessonId") ?: 0
            QuizScreen(
                lessonId = lessonId,
                onFinish = {
                    navController.popBackStack(Screen.Home.route, false)
                },
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(Screen.Progress.route) {
            ProgressScreen(
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(Screen.MultiMeaning.route) {
            MultiMeaningScreen(
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.Vocabulary.route,
            arguments = listOf(navArgument("lessonId") { type = NavType.IntType })
        ) { backStackEntry ->
            val lessonId = backStackEntry.arguments?.getInt("lessonId") ?: 0
            VocabularyScreen(
                lessonId = lessonId,
                onBackClick = { navController.popBackStack() }
            )
        }
    }
}
