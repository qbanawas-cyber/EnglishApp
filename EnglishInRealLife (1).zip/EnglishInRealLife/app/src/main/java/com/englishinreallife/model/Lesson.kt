package com.englishinreallife.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lessons")
data class Lesson(
    @PrimaryKey
    val id: Int,
    val category: String,
    val title: String,
    val titleAr: String,
    val description: String,
    val descriptionAr: String,
    val difficulty: DifficultyLevel,
    val orderIndex: Int,
    val isCompleted: Boolean = false,
    val pointsEarned: Int = 0
)

enum class DifficultyLevel {
    BEGINNER, INTERMEDIATE, ADVANCED
}
