package com.englishinreallife.data.local.dao

import androidx.room.*
import com.englishinreallife.model.Quiz
import kotlinx.coroutines.flow.Flow

@Dao
interface QuizDao {

    @Query("SELECT * FROM quizzes WHERE lessonId = :lessonId")
    fun getQuizzesForLesson(lessonId: Int): Flow<List<Quiz>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuizzes(quizzes: List<Quiz>)

    @Query("SELECT COUNT(*) FROM quizzes WHERE lessonId = :lessonId")
    suspend fun getQuizCountForLesson(lessonId: Int): Int
}
