package com.englishinreallife.data.local.dao

import androidx.room.*
import com.englishinreallife.model.Vocabulary
import kotlinx.coroutines.flow.Flow

@Dao
interface VocabularyDao {

    @Query("SELECT * FROM vocabulary WHERE lessonId = :lessonId")
    fun getVocabularyForLesson(lessonId: Int): Flow<List<Vocabulary>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVocabulary(vocab: List<Vocabulary>)

    @Query("SELECT * FROM vocabulary WHERE word LIKE '%' || :query || '%' OR meaning LIKE '%' || :query || '%'")
    fun searchVocabulary(query: String): Flow<List<Vocabulary>>
}
