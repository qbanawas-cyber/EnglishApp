package com.englishinreallife.data.local.dao

import androidx.room.*
import com.englishinreallife.model.DialogueLine
import kotlinx.coroutines.flow.Flow

@Dao
interface DialogueDao {

    @Query("SELECT * FROM dialogue_lines WHERE lessonId = :lessonId ORDER BY orderIndex ASC")
    fun getDialogueForLesson(lessonId: Int): Flow<List<DialogueLine>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDialogueLines(lines: List<DialogueLine>)

    @Query("DELETE FROM dialogue_lines WHERE lessonId = :lessonId")
    suspend fun deleteDialogueForLesson(lessonId: Int)
}
