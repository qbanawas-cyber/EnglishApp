package com.englishinreallife.ui.navigation

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Lessons : Screen("lessons/{category}") {
        fun createRoute(category: String) = "lessons/$category"
    }
    data object LessonDetail : Screen("lesson/{lessonId}") {
        fun createRoute(lessonId: Int) = "lesson/$lessonId"
    }
    data object Quiz : Screen("quiz/{lessonId}") {
        fun createRoute(lessonId: Int) = "quiz/$lessonId"
    }
    data object Progress : Screen("progress")
    data object MultiMeaning : Screen("multi_meaning")
    data object Vocabulary : Screen("vocabulary/{lessonId}") {
        fun createRoute(lessonId: Int) = "vocabulary/$lessonId"
    }
}
