package com.englishinreallife.data.local.dao

import androidx.room.*
import com.englishinreallife.model.Lesson
import kotlinx.coroutines.flow.Flow

@Dao
interface LessonDao {

    @Query("SELECT * FROM lessons ORDER BY orderIndex ASC")
    fun getAllLessons(): Flow<List<Lesson>>

    @Query("SELECT * FROM lessons WHERE category = :category ORDER BY orderIndex ASC")
    fun getLessonsByCategory(category: String): Flow<List<Lesson>>

    @Query("SELECT * FROM lessons WHERE id = :id")
    suspend fun getLessonById(id: Int): Lesson?

    @Query("SELECT DISTINCT category FROM lessons ORDER BY orderIndex")
    fun getAllCategories(): Flow<List<String>>

    @Query("SELECT COUNT(*) FROM lessons WHERE isCompleted = 1")
    fun getCompletedLessonsCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM lessons")
    fun getTotalLessonsCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLessons(lessons: List<Lesson>)

    @Update
    suspend fun updateLesson(lesson: Lesson)

    @Query("UPDATE lessons SET isCompleted = 1, pointsEarned = :points WHERE id = :lessonId")
    suspend fun markLessonComplete(lessonId: Int, points: Int)

    @Query("SELECT * FROM lessons WHERE isCompleted = 0 ORDER BY orderIndex LIMIT 1")
    suspend fun getNextLesson(): Lesson?
}
