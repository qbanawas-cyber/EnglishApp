package com.englishinreallife.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.englishinreallife.data.local.dao.*
import com.englishinreallife.model.*

@Database(
    entities = [
        Lesson::class,
        DialogueLine::class,
        Vocabulary::class,
        Quiz::class,
        MultiMeaningWord::class,
        UserProgress::class,
        Achievement::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun lessonDao(): LessonDao
    abstract fun dialogueDao(): DialogueDao
    abstract fun vocabularyDao(): VocabularyDao
    abstract fun quizDao(): QuizDao
    abstract fun multiMeaningDao(): MultiMeaningDao
    abstract fun progressDao(): ProgressDao
    abstract fun achievementDao(): AchievementDao
}
