package com.englishinreallife.ui.screens.lessons

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.englishinreallife.ui.components.*
import com.englishinreallife.ui.theme.getCategoryColor
import com.englishinreallife.viewmodel.HomeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonsScreen(
    category: String,
    onLessonClick: (Int) -> Unit,
    onBackClick: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val lessons by viewModel.getLessonsByCategory(category).collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            AppTopBar(
                title = category,
                subtitle = getCategoryArabicName(category),
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        if (lessons.isEmpty()) {
            EmptyState(
                icon = Icons.Default.Book,
                title = "No Lessons Yet",
                message = "Lessons for this category will be available soon!",
                modifier = Modifier.padding(padding)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = "${lessons.size} Lessons Available",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                items(lessons) { lesson ->
                    LessonCard(
                        title = lesson.title,
                        titleAr = lesson.titleAr,
                        description = lesson.description,
                        isCompleted = lesson.isCompleted,
                        points = lesson.pointsEarned,
                        difficulty = lesson.difficulty.name,
                        onClick = { onLessonClick(lesson.id) }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}

fun getCategoryArabicName(category: String): String = when (category) {
    "Greetings" -> "التحيات"
    "Family" -> "العائلة"
    "Restaurant" -> "المطعم"
    "Shopping" -> "التسوق"
    "Travel" -> "السفر"
    "Hotel" -> "الفندق"
    "Work" -> "العمل"
    "Emergencies" -> "الطوارئ"
    "Airport" -> "المطار"
    "Daily Life" -> "الحياة اليومية"
    else -> category
}
