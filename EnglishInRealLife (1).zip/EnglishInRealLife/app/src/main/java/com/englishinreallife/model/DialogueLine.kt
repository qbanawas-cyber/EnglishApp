package com.englishinreallife.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "dialogue_lines",
    foreignKeys = [
        ForeignKey(
            entity = Lesson::class,
            parentColumns = ["id"],
            childColumns = ["lessonId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("lessonId")]
)
data class DialogueLine(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val lessonId: Int,
    val speaker: String,
    val english: String,
    val arabic: String,
    val orderIndex: Int,
    val audioPath: String? = null
)
