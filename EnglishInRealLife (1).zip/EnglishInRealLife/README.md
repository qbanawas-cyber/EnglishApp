# English in Real Life - Android App

A modern Android application for complete beginners to learn English through real-life situations and daily conversations. Built with Kotlin, Jetpack Compose, Room, and MVVM architecture.

## Features

### MVP Features (Completed)
- **20 Complete Lessons** across 10 categories (Greetings, Family, Restaurant, Shopping, Travel, Hotel, Work, Emergencies, Airport, Daily Life)
- **Bilingual Content** - Every sentence has English + Arabic translation
- **Interactive Dialogues** - Real-life conversations with audio support placeholders
- **Vocabulary System** - Key words with pronunciation, meanings, and examples
- **Quiz System** - Multiple choice, word ordering, fill-in-the-blank exercises
- **Points & Progress** - Earn points, track levels, maintain streaks
- **Achievement System** - 7 unlockable badges
- **Multi-Meaning Words** - Special section for words with multiple meanings (Book, Watch, Play, Bank, Right, Date)
- **Dark Mode Support** - Full theme adaptation
- **Local Data Storage** - Room database with offline capability

## Architecture

```
EnglishInRealLife/
├── app/src/main/java/com/englishinreallife/
│   ├── data/
│   │   ├── local/          # Room Database, DAOs, DataSeeder
│   │   └── repository/     # Repository pattern implementation
│   ├── model/              # Data classes (Lesson, Quiz, Vocabulary, etc.)
│   ├── di/                 # Hilt Dependency Injection
│   ├── ui/
│   │   ├── components/     # Reusable UI components
│   │   ├── navigation/     # Navigation graph
│   │   ├── screens/        # Feature screens
│   │   └── theme/          # Colors, Typography, Theme
│   ├── viewmodel/          # MVVM ViewModels
│   ├── EnglishApp.kt       # Application class
│   └── MainActivity.kt     # Entry point
└── app/src/main/res/       # Strings, themes, resources
```

## Tech Stack

- **Language**: Kotlin
- **UI**: Jetpack Compose with Material Design 3
- **Architecture**: MVVM + Repository Pattern
- **Database**: Room (SQLite)
- **DI**: Hilt
- **Navigation**: Compose Navigation
- **Async**: Kotlin Coroutines & Flow
- **Serialization**: Kotlinx Serialization

## Setup Instructions

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or newer
- JDK 17
- Android SDK 34
- Minimum device: Android 7.0 (API 24)

### Installation

1. **Clone or download** this project folder

2. **Open in Android Studio**:
   ```bash
   File → Open → Select the EnglishInRealLife folder
   ```

3. **Sync Gradle**:
   - Android Studio will automatically prompt to sync
   - Click "Sync Now" in the notification bar
   - Wait for dependencies to download (may take 5-10 minutes first time)

4. **Build the project**:
   ```bash
   Build → Make Project (Ctrl+F9)
   ```

5. **Run on device or emulator**:
   ```bash
   Run → Run 'app' (Shift+F10)
   ```

### Project Structure Details

#### Data Layer
- **Room Database**: `AppDatabase` with 7 entities
- **DAOs**: LessonDao, DialogueDao, VocabularyDao, QuizDao, MultiMeaningDao, ProgressDao
- **DataSeeder**: Pre-populates 20 lessons, dialogues, vocabulary, quizzes, and achievements on first launch
- **Repositories**: Abstract data operations, expose Flows for reactive UI

#### UI Layer
- **HomeScreen**: Dashboard with categories, progress, quick actions
- **LessonsScreen**: Category-specific lesson list
- **LessonDetailScreen**: Dialogue viewer with vocabulary preview
- **VocabularyScreen**: Full vocabulary list for a lesson
- **QuizScreen**: Interactive quiz with multiple question types
- **ProgressScreen**: Stats, achievements, level tracking
- **MultiMeaningScreen**: Special section for ambiguous words

#### ViewModels
- **HomeViewModel**: Manages categories, lessons, progress overview
- **LessonViewModel**: Handles lesson content, dialogues, vocabulary
- **QuizViewModel**: Quiz state management, scoring, answer tracking
- **ProgressViewModel**: User stats, achievements, streak calculation
- **MultiMeaningViewModel**: Search and filter multi-meaning words

## How to Expand to Professional Product

### Phase 1: Content Expansion (Weeks 1-2)
1. **Add More Lessons**: Expand to 100+ lessons across 20+ categories
   - Add lessons: Doctor, Bank, School, Weather, Time, Colors, Numbers, etc.
   - Each lesson needs: dialogue, vocabulary, 3-5 quizzes

2. **Richer Dialogues**: 
   - Add more characters per dialogue
   - Include cultural notes and context
   - Add "Common Mistakes" section

3. **Audio Integration**:
   - Integrate Google Text-to-Speech (TTS) API
   - Add native speaker recordings
   - Implement pronunciation scoring using Speech-to-Text

### Phase 2: Feature Enhancement (Weeks 3-4)
1. **Advanced Quiz Types**:
   - Listening comprehension (audio + questions)
   - Speaking exercises (record and compare)
   - Writing exercises with auto-correction
   - True/False questions

2. **Gamification**:
   - Daily challenges
   - Leaderboards (local and global)
   - Weekly competitions
   - Virtual currency for shop items

3. **AI Integration**:
   - Chatbot for conversation practice
   - Grammar correction using ML Kit
   - Personalized learning path based on performance
   - Smart review scheduling (spaced repetition)

### Phase 3: User Experience (Weeks 5-6)
1. **User Accounts**:
   - Firebase Authentication (Google, Email, Anonymous)
   - Cloud sync across devices
   - Backup/restore progress

2. **Offline-First Improvements**:
   - Download lessons for offline use
   - Background sync when online
   - Progressive download manager

3. **Accessibility**:
   - Screen reader optimization
   - Font size controls
   - High contrast mode
   - Voice navigation

### Phase 4: Monetization & Publishing (Weeks 7-8)
1. **Freemium Model**:
   - Free: 20 lessons + basic features
   - Premium: All lessons + advanced features + no ads
   - Subscription tiers: Monthly/Yearly/Lifetime

2. **Ad Integration**:
   - Google AdMob (banner, interstitial, rewarded)
   - Rewarded ads for bonus points
   - Premium removes all ads

3. **Google Play Preparation**:
   - Create developer account ($25 one-time fee)
   - Generate signed APK/AAB
   - Prepare screenshots (phone + tablet)
   - Write store description in English and Arabic
   - Set up in-app purchases
   - Configure Firebase Crashlytics
   - Implement analytics (Firebase Analytics)

### Phase 5: Marketing & Growth (Ongoing)
1. **ASO (App Store Optimization)**:
   - Keywords: "learn English", "English for beginners", "English conversation"
   - Arabic keywords: "تعلم الإنجليزية", "الإنجليزية للمبتدئين"
   - A/B test icons and screenshots

2. **Social Features**:
   - Share progress on social media
   - Invite friends for bonus points
   - Study groups and challenges

3. **Content Updates**:
   - Monthly new lessons
   - Seasonal content (holiday vocabulary)
   - User-requested topics
   - Community-contributed dialogues

## Key Implementation Notes

### Adding New Lessons
Edit `DataSeeder.kt` and add to the `lessons` list:
```kotlin
Lesson(21, "NewCategory", "Lesson Title", "العنوان بالعربي",
    "Description", "الوصف بالعربي", DifficultyLevel.BEGINNER, 21)
```

Then add corresponding dialogues, vocabulary, and quizzes.

### Adding Audio
Replace the placeholder audio button with:
```kotlin
val tts = TextToSpeech(context) { status ->
    if (status == TextToSpeech.SUCCESS) {
        tts.language = Locale.US
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
    }
}
```

### Adding Firebase
1. Add to `build.gradle` (Project):
   ```kotlin
   id("com.google.gms.google-services") version "4.4.0" apply false
   ```
2. Add to `build.gradle` (App):
   ```kotlin
   implementation(platform("com.google.firebase:firebase-bom:32.7.0"))
   implementation("com.google.firebase:firebase-auth-ktx")
   implementation("com.google.firebase:firebase-firestore-ktx")
   ```
3. Download `google-services.json` from Firebase Console and place in `app/`

### Generating Release Build
```bash
# In Android Studio
Build → Generate Signed Bundle / APK
→ Select APK or Android App Bundle
→ Create new keystore or use existing
→ Select release build variant
→ Finish
```

## License

MIT License - Free for personal and commercial use.

## Support

For issues or feature requests, please contact the development team.

---

**Built with ❤️ for English learners worldwide**
